#!/usr/bin/env python
# coding: utf-8

# In[1]:


import random

# Function to greet the user
def greet():
    greetings = ["Hello! How can I help you?", "Welcome! What can I assist you with?", "Hi there! How may I assist you today?"]
    return random.choice(greetings)

# Function to provide different responses based on user input
def respond(input_text):
    if "how are you" in input_text.lower():
        return "I'm good. How about you?"
    elif "where are you from" in input_text.lower() or "place" in input_text.lower():
        return "i'm artificial intelligence"
    elif "can you guess weather" in input_text.lower() or "temperature" in input_text.lower():
        return "I'm afraid I'm not equipped to provide weather information."
    elif "joke" in input_text.lower():
        return "Why don't scientists trust atoms? Because they make up everything!"
    elif "farewell" in input_text.lower() or "goodbye" in input_text.lower():
        return "Goodbye! Have a great day!"
    else:
        return "I'm sorry, I don't understand. Can you please rephrase your question?"

# Function to handle user interaction
def chat():
    print(greet())
    
    while True:
        user_input = input()
        response = respond(user_input)
        print(response)
        
        if "farewell" in user_input.lower() or "goodbye" in user_input.lower():
            break

# Start the chat
chat()


# In[ ]:




